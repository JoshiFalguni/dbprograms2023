//Create a parameterized stored procedure to reduce the price of a
//company's products by a specified amount. Call the SP from a
//program

//delimiter //
//create procedure updateprice(comp varchar(10),amount float)
//begin 
//update mobile set price=price-amount 
//where company=comp; 
//end//
//delimiter ;




package com.jdbc.crudoperations;

import java.sql.*;


public class Question8 {
public static void main(String[] args) {
 Connection con;
 CallableStatement cst;
 
 try {
	 Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://ba1jjzz5s88js0pwewil-mysql.services.clever-cloud.com:3306/ba1jjzz5s88js0pwewil?user=udwa7zkw5qmzqnv9&password=NHDWL0kSXweTWCK97Wg6");
		
	 cst=con.prepareCall("{call updateprice(vivo,999)}");
	 cst.execute();
	 System.out.println("Price updated");
	 con.close();
 }catch(Exception e)
 {
	 System.out.println(e);
 }
}
}
