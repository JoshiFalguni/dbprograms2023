//Write a program to accept prodid, display the mobile data and ask
//"Do you want to delete?" if "yes" delete the mobile from the table


package com.jdbc.crudoperations;

import java.sql.*;
import java.util.*;

public class Question6 {
	public static void main(String[] args) {
		Connection con;
		PreparedStatement pst,pst1;
		ResultSet rs ;
		Scanner sc=new Scanner(System.in);
		
		int pid;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://ba1jjzz5s88js0pwewil-mysql.services.clever-cloud.com:3306/ba1jjzz5s88js0pwewil?user=udwa7zkw5qmzqnv9&password=NHDWL0kSXweTWCK97Wg6");
			pst=con.prepareStatement("select * from mobile where prodid=?");
			
			System.out.println("Enter product id:");
			pid=sc.nextInt();
			
			pst.setInt(1, pid);
			rs=pst.executeQuery();
			while(rs.next())
			{
				System.out.print(rs.getInt("prodid")+" | ");
				System.out.print(rs.getString("modelname")+" | ");
				System.out.print(rs.getString("company")+" | ");
				System.out.print(rs.getString("connectivity")+" | ");
				System.out.print(rs.getString("ram")+" | ");
				System.out.print(rs.getString("rom")+" | ");
				System.out.print(rs.getString("color")+" | ");
				System.out.print(rs.getString("screen")+" | ");
				System.out.print(rs.getString("battery")+" | ");
				System.out.print(rs.getString("processor")+" | ");
				System.out.print(rs.getFloat("price")+" | ");
				System.out.println(rs.getFloat("ratings"));
			}
			System.out.println("Do you want to delete?");
			
			
			
				pst1=con.prepareStatement("delete from mobile where prodid=?");
				pst1.setInt(1, pid);
				int cnt=pst1.executeUpdate();
				if(cnt>0)
				{
					System.out.println("data deleted");
				}
			
			
			
			
			
			con.close();
			sc.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
