//Write a program to accept modelname, search mobile in the table,
//show the mobile details if found else display "not found" message



package com.jdbc.crudoperations;
import java.sql.*;
import java.util.Scanner;

public class Question3 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	
	String model_nm;
	 
    try {
    	Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://ba1jjzz5s88js0pwewil-mysql.services.clever-cloud.com:3306/ba1jjzz5s88js0pwewil?user=udwa7zkw5qmzqnv9&password=NHDWL0kSXweTWCK97Wg6");
		pst=con.prepareStatement("select * from mobile where modelname=?");
		
		System.out.println("Enter model name: ");
		model_nm=sc.nextLine();
		
		pst.setString(1, model_nm);
		rs=pst.executeQuery();
		
		
		if(rs.next())
		{
			System.out.print(rs.getInt("prodid")+" | ");
			System.out.print(rs.getString("modelname")+" | ");
			System.out.print(rs.getString("company")+" | ");
			System.out.print(rs.getString("connectivity")+" | ");
			System.out.print(rs.getString("ram")+" | ");
			System.out.print(rs.getString("rom")+" | ");
			System.out.print(rs.getString("color")+" | ");
			System.out.print(rs.getString("screen")+" | ");
			System.out.print(rs.getString("battery")+" | ");
			System.out.print(rs.getString("processor")+" | ");
			System.out.print(rs.getFloat("price")+" | ");
			System.out.print(rs.getFloat("ratings"));
		}
		else
		{
			System.out.println("not found");
		}
    	con.close();
    	sc.close();
    }catch(Exception e)
    {
    	System.out.println(e);
    }
}
}
