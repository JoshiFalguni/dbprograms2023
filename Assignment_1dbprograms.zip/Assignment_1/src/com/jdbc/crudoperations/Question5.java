//Write a program to accept prodid & new price and update price in
//the mobile data in the table if found else display "mobile does not
//exist"


package com.jdbc.crudoperations;

import java.sql.*;
import java.util.Scanner;

public class Question5 {
	public static void main(String[] args) {
		Connection con;
		PreparedStatement pst;
		
		
		Scanner sc= new Scanner(System.in);
		
		int pid;
		float price;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://ba1jjzz5s88js0pwewil-mysql.services.clever-cloud.com:3306/ba1jjzz5s88js0pwewil?user=udwa7zkw5qmzqnv9&password=NHDWL0kSXweTWCK97Wg6");
			pst=con.prepareStatement("update mobile set price=? where prodid=?");
			
			System.out.print("Enter product id: ");
			pid=sc.nextInt();
			System.out.println("Enter new price: ");
			price=sc.nextFloat();
			
			pst.setFloat(1, price);
			pst.setInt(2, pid);
			
			int cnt=pst.executeUpdate();
			System.out.println(cnt);
			
			if(cnt==1)	
			System.out.println("Price changed successfully");
			else
				System.out.println("mobile does not exist");
			
			con.close();
			sc.close();
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
