//Write a program to accept company like "samsung" and display list
//of mobiles of that category in the ascending order of price


package com.jdbc.crudoperations;

import java.sql.*;
import java.util.Scanner;

public class Question4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		String comp;
		
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://ba1jjzz5s88js0pwewil-mysql.services.clever-cloud.com:3306/ba1jjzz5s88js0pwewil?user=udwa7zkw5qmzqnv9&password=NHDWL0kSXweTWCK97Wg6");
			pst=con.prepareStatement("select modelname from mobile where company=? order by price asc");
			
			System.out.println("Enter company name: ");
			comp=sc.nextLine();
			
			pst.setString(1, comp);
			rs=pst.executeQuery();
			
			while(rs.next())
			{
				System.out.println(rs.getString("modelname"));
			}
			
			con.close();
			sc.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
