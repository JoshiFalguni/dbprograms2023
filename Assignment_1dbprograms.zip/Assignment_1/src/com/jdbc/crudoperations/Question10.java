//Write a program to display group by information - brand, total
//models under the company, average price and average rating


package com.jdbc.crudoperations;

import java.sql.*;
import java.util.Scanner;

public class Question10 { 
	public static void main(String[] args) {
		Connection con;
		Statement st;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://ba1jjzz5s88js0pwewil-mysql.services.clever-cloud.com:3306/ba1jjzz5s88js0pwewil?user=udwa7zkw5qmzqnv9&password=NHDWL0kSXweTWCK97Wg6");
			
			st=con.createStatement();
			rs=st.executeQuery("select * from mobile where group by AVG(price) and AVG(ratings) ");
			while(rs.next())
			{
				System.out.println(rs.getString("company")+" | "+rs.getString("modelname")+" | ");
			}
			con.close();
			
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
