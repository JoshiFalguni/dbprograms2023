//Write a program to accept ram and rom, display list of mobiles of
//the ram-rom storage space combination


package com.jdbc.crudoperations;

import java.sql.*;
import java.util.*;

public class Question7 {
public static void main(String[] args) {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	
	Scanner sc=new Scanner(System.in);
	String rom,ram;
	
	try
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://ba1jjzz5s88js0pwewil-mysql.services.clever-cloud.com:3306/ba1jjzz5s88js0pwewil?user=udwa7zkw5qmzqnv9&password=NHDWL0kSXweTWCK97Wg6");
		pst=con.prepareStatement("select modelname,ram,rom  from mobile where ram=? and rom=?");
		
		System.out.println("Enter ram: ");
		ram=sc.nextLine();
		System.out.println("Enter rom: ");
		rom=sc.nextLine();
		
		pst.setString(1,ram);
		pst.setString(2,rom);
		rs=pst.executeQuery();
		
		while(rs.next())
		{
			System.out.println(rs.getString("modelname"));
		}
		con.close();
		sc.close();
		
	}catch(Exception e)
	{
		System.out.println(e);
	}
}
}
