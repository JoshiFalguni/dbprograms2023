//Write a program to show list of all mobiles


package com.jdbc.crudoperations;
import java.sql.*;

public class Question2 {
public static void main(String[] args) {
	Connection con;
	Statement st;
	ResultSet rs;
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://ba1jjzz5s88js0pwewil-mysql.services.clever-cloud.com:3306/ba1jjzz5s88js0pwewil?user=udwa7zkw5qmzqnv9&password=NHDWL0kSXweTWCK97Wg6");
		
		st=con.createStatement();
		rs=st.executeQuery("select * from mobile");
		
		while(rs.next())
		{
			System.out.println(rs.getString("modelname")+" | ");
			System.out.println(rs.getString("company"));
		}
		con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
}
}
