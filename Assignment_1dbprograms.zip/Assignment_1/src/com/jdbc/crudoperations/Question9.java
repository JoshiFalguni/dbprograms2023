//Write a program to accept modelname and purpose, update all
//mobiles of the model with the purpose ( gaming/office/social, etc.)



package com.jdbc.crudoperations;

import java.sql.*;
import java.util.Scanner;

public class Question9 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		Connection con;
		PreparedStatement pst;
		
		
		String model_nm,purpose;
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://ba1jjzz5s88js0pwewil-mysql.services.clever-cloud.com:3306/ba1jjzz5s88js0pwewil?user=udwa7zkw5qmzqnv9&password=NHDWL0kSXweTWCK97Wg6");
			pst=con.prepareStatement("update mobile set purpose=? where modelname=?");
			
			System.out.println("Enter modelname: ");
			model_nm=sc.nextLine();
			
			System.out.println("Enter purpose: ");
			purpose=sc.nextLine();
			
			pst.setString(1, purpose);
			pst.setString(2, model_nm);
			int c =pst.executeUpdate();
			
			System.out.println("Data is updated");
			
			con.close();
			sc.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	
}
