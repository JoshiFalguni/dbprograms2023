//Take field as an input like rom and display all mobiles in the
//descending order of the that field.


package com.jdbc.crudoperations;

import java.sql.*;
import java.util.Scanner;

public class Question11 {
public static void main(String[] args) {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String rom;
	
	Scanner sc= new Scanner(System.in);
	
	try
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://ba1jjzz5s88js0pwewil-mysql.services.clever-cloud.com:3306/ba1jjzz5s88js0pwewil?user=udwa7zkw5qmzqnv9&password=NHDWL0kSXweTWCK97Wg6");
		pst=con.prepareStatement("select modelname from mobile where rom=? order by rom desc");
		
		System.out.println("Enter rom: ");
		rom=sc.nextLine();
		
		pst.setString(1,rom);
		rs=pst.executeQuery();
		
		while(rs.next())
		{
			System.out.println(rs.getString("modelname"));
		}
		
		con.close();
		sc.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
}
}
